package com.mococo.webview;

public interface WebViewBridge {
    String webViewToApp(String token);
}
